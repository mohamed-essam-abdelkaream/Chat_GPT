
class boardingModel {
  final String imageResId2;
  final String text2 ;
  final String text3;
  final String text4;
  final String text5;

  boardingModel({
    required this.imageResId2,
    required this.text2,
    required this.text3,
    required this.text4,
    required this.text5,
  });
}
