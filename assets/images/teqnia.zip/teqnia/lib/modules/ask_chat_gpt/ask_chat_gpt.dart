import 'package:flutter/material.dart';
class AskChatGpt extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xff202123),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_outlined, size: 15,),
                    onPressed: (){
                      Navigator.pop(context);
                    },
                  ),
                  const Padding(
                    padding: EdgeInsets.all(15.0),
                    child: Text(
                      'Back',
                      style: TextStyle(
                          fontSize: 16,
                          fontFamily: 'Raleway',
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  Spacer(),
                  const Image(
                    image: AssetImage('assets/images/Vector.png'),
                    width: 15,
                    height: 15,
                  ),
                ],
              ),
              Container(
                  width: double.infinity,
                  height: 1,
                  decoration: const BoxDecoration(color: Colors.grey)),

            ],
          ),
        ),
      ),
    );
  }
}