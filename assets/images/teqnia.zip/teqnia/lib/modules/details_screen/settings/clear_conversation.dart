import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ClearConversation extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Image(
          image: AssetImage('assets/images/clear.png'),
          width: 20,
          height: 20,
        ),
        Padding(
          padding: EdgeInsets.all(15.0),
          child: Text(
            'Clear conversation',
            style: TextStyle(
                fontSize: 16,
                fontFamily: 'Raleway',
                fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}